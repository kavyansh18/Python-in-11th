print("Lets Start")
print()
import random
kavyansh=0
system=0
anu=0
shirin=0
while kavyansh!=100 or system!=100 or anu!=100 or shirin!=0:
  n=random.randint(1,6)
  print("system got",n)
  system+=n
  if system==4:
   print("System got a ladder")
   system=14
  elif system==9:
   print("System got a ladder") 
   system=31
  elif system==2:
   print("System  got a ladder") 
   system=38
  elif system==21:
   print("System got a ladder") 
   system=42
  elif system==28:
   print("System got a ladder") 
   system=84
  elif system==51:
   print("System got a ladder") 
   system=67
  elif system==72:
   print("System got a ladder") 
   system=91
  elif system==80:
   print("System got a ladder") 
   system=99
  if system==17:
   print("snake bitted system")
   system=7
  elif system==53:
   print("snake bitted system") 
   system=34
  elif system==62:
   print("snake bitted system") 
   system=19
  elif system==64:
   print("snake bitted system") 
   system=60
  elif system==87:
   print("snake bitted system") 
   system=36
  elif system==93:
   print("snake bitted system") 
   system=73
  elif system==95:
   print("snake bitted system") 
   system=75
  elif system==98:
   print("snake bitted system") 
   system=79
  print("system score =",system)
  print()
  if system>=100:
    print("system won the game")
    break
  n1=random.randint(1,6)
  print("Kavyansh got",n1)
  kavyansh+=n1
  if kavyansh==4:
   print("Congratulations! kavyansh got a ladder")
   kavyasnh=14
  elif kavyansh==9:
   print("Congratulations! kavyansh got a ladder") 
   kavyansh=31
  elif kavyansh==2:
   print("Congratulations! kavyansh got a ladder") 
   kavyansh=38
  elif kavyansh==21:
   print("Congratulations! kavyansh got a ladder") 
   kavyansh=42
  elif kavyansh==28:
   print("Congratulations! kavyansh got a ladder") 
   kavyansh=84
  elif kavyansh==51:
   print("Congratulations! kavyansh got a ladder") 
   kavyansh=67
  elif kavyansh==72:
   print("Congratulations! kavyansh got a ladder") 
   kavyansh=91
  elif kavyansh==80:
   print("Congratulations! kavyansh got a ladder") 
   kavyansh=99
  if kavyansh==17:
   print("ohh no snake bitted kavyansh")
   kavyansh=7
  elif kavyansh==53:
   print("ohh no snake bitted kavyansh") 
   kavyansh=34
  elif kavyansh==62:
   print("ohh no snake bitted kavyansh")
   kavyansh=19
  elif kavyansh==64:
   print("ohh no snake bitted kavyansh") 
   kavyansh=60
  elif kavyansh==87:
   print("ohh no snake bitted kavyansh") 
   kavyansh=36
  elif kavyansh==93:
   print("ohh no snake bitted kavyansh") 
   kavyansh=73
  elif kavyansh==95:
   print("ohh no snake bitted kavyansh") 
   kavyansh=75
  elif kavyansh==98:
   print("ohh no snake bitted kavyansh") 
   kavyansh=79
  print("kavyansh score =",kavyansh)
  print()
  if kavyansh>=100:
    print("kavyansh won the game")
    break
  n1=random.randint(1,6)
  print("Anu got",n1)
  anu+=n1
  if anu==4:
   print("Congratulations! anu got a ladder")
   anu=14
  elif anu==9:
   print("Congratulations! anu got a ladder") 
   anu=31
  elif anu==2:
   print("Congratulations! anu got a ladder") 
   anu=38
  elif anu==21:
   print("Congratulations! anu got a ladder") 
   anu=42
  elif anu==28:
   print("Congratulations! anu got a ladder") 
   anu=84
  elif anu==51:
   print("Congratulations! anu got a ladder") 
   anu=67
  elif anu==72:
   print("Congratulations! anu got a ladder") 
   anu=91
  elif anu==80:
   print("Congratulations! anu got a ladder") 
   anu=99
  if anu==17:
   print("ohh no snake bitted anu")
   anu=7
  elif anu==53:
   print("ohh no snake bitted anu") 
   anu=34
  elif anu==62:
   print("ohh no snake bitted anu") 
   anu=19
  elif anu==64:
   print("ohh no snake bitted anu") 
   anu=60
  elif anu==87:
   print("ohh no snake bitted anu") 
   anu=36
  elif anu==93:
   print("ohh no snake bitted anu") 
   anu=73
  elif anu==95:
   print("ohh no snake bitted anu") 
   anu=75
  elif anu==98:
   print("ohh no snake bitted anu") 
   anu=79
  print("anu score =",anu)
  print()
  if anu>=100:
    print("anu won the game")
    break
  n1=random.randint(1,6)
  print("Shirin got",n1)
  shirin+=n1
  if shirin==4:
   print("Congratulations! shirin got a ladder")
   shirin=14
  elif shirin==9:
   print("Congratulations! shirin got a ladder") 
   shirin=31
  elif shirin==2:
   print("Congratulations! shirin got a ladder") 
   shirin=38
  elif shirin==21:
   print("Congratulations! shirin got a ladder") 
   shirin=42
  elif shirin==28:
   print("Congratulations! shirin got a ladder") 
   shirin=84
  elif shirin==51:
   print("Congratulations! shirin got a ladder") 
   shirin=67
  elif shirin==72:
   print("Congratulations! shirin got a ladder") 
   shirin=91
  elif shirin==80:
   print("Congratulations! shirin got a ladder") 
   shirin=99
  if shirin==17:
   print("ohh no snake bitted shirin")
   shirin=7
  elif shirin==53:
   print("ohh no snake bitted shirin") 
   shirin=34
  elif shirin==62:
   print("ohh no snake bitted shirin") 
   shirin=19
  elif shirin==64:
   print("ohh no snake bitted shirin") 
   shirin=60
  elif shirin==87:
   print("ohh no snake bitted shirin")
   shirin=36
  elif shirin==93:
   print("ohh no snake bitted shirin") 
   shirin=73
  elif shirin==95:
   print("ohh no snake bitted shirin") 
   shirin=75
  elif shirin==98:
   print("ohh no snake bitted shirin") 
   shirin=79
  print("Shirin score =",shirin)
  print()
  if shirin>=100:
    print("shirin won the game")
    break
print()
print("Score of kavyansh is ",kavyansh)
print("Score of system is ",system)
print("Score of anu is ",anu)
print("Score of shirin is ",shirin)
print("GAME OVER")
